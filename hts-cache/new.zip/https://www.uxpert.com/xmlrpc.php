<!doctype html>
<html class="no-js">
<head>
    <script>
        var strings = {
            'en': {
                'dir': 'ltr',
                'tld': 'io',
                'title': '403 Forbidden',
                'where_to': '403 Forbidden',
                'access_denied': 'You are not authorized to perform this action,',
                'contact_webmaster': 'Please contact the webmaster.',
                'your_ip_is': 'Your IP address is',
            },
            'he': {
                'dir': 'rtl',
                'tld': 'co.il',
                'title': '403 הגישה נחסמה',
                'where_to': 'שגיאה 403',
                'access_denied': 'אינך מורשה לבצע פעולה זו,',
                'contact_webmaster': 'אנא צור קשר עם מנהל האתר.',
                'your_ip_is': 'כתובת הIP שלך היא',
            }
        };
        var lang = window.navigator.languages.indexOf('he') >= 0 ? 'he' : 'en';
        var strings = strings[lang];
    </script>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width,initial-scale=0.86,maximum-scale=3,minimum-scale=0.86">
    <title>Forbidden</title>
    <link rel="icon" href="https://www.upress.io/wp-content/uploads/2018/05/favicon.png">
    <link rel="apple-touch-icon-precomposed" href="https://www.upress.io/wp-content/uploads/2018/05/favicon.png">
    <link rel="apple-touch-icon" href="https://www.upress.io/wp-content/uploads/2018/05/apple-touch-icon.png">
    <meta name="robots" content="none">
    <link href="https://fonts.googleapis.com/css?family=Heebo" rel="stylesheet">
    <style>blockquote,body,dd,dl,dt,fieldset,figure,h1,h2,h3,h4,h5,h6,hr,html,iframe,legend,li,ol,p,pre,textarea,ul{margin:0;padding:0}h1,h2,h3,h4,h5,h6{font-size:100%;font-weight:400}ul{list-style:none}button,input,select,textarea{margin:0}html{box-sizing:border-box}*,:after,:before{box-sizing:inherit}audio,embed,iframe,img,object,video{height:auto;max-width:100%}iframe{border:0}table{border-collapse:collapse;border-spacing:0}td,th{padding:0;text-align:left}html{font-size:62.5%;min-width:300px}body,html{width:100%;box-sizing:border-box;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-rendering:optimizeLegibility}body{background:#f5f7fa;height:100%;font-size:1.6rem;font-family:Heebo,sans-serif;-ms-overflow-style:none;overflow:-moz-scrollbars-none;overflow:hidden}.grid-background{background-image:linear-gradient(90deg,#fff 1px,transparent 0),linear-gradient(#fff 1px,transparent 0);background-size:30px 30px;position:absolute;top:-70rem;left:-22rem;transform:skewY(25deg) skewX(-40.3deg) rotate(6deg);transform-origin:center center;pointer-events:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border-radius:0 0 100vw 0;z-index:-1;border-radius:100vw/100vw;height:140rem;width:100%}svg#client-leave{min-width:1900px;max-width:1900px;position:absolute;left:50%;top:0;transform:translate(-50%)}#balloon-container{transform-origin:top center;animation:balloonRotate 80s infinite ease-in-out}.content{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);text-align:center;font-size:1.8rem;direction:ltr;line-height:1.5;min-width:300px;max-width:600px;display:-ms-flexbox;display:flex;-ms-flex-pack:justify;justify-content:space-between;-ms-flex-direction:column;flex-direction:column;text-shadow:0 2px 1px rgba(0,0,0,.1);-ms-flex-align:center;align-items:center}.content #upress-tobocat{width:120px;margin-bottom:20px}.content ::-moz-selection{background:#e7eef6}.content ::selection{background:#e7eef6}.content h1{font-size:2.3rem;color:#000}.content h2{margin:0 0 8px;color:#72737a;text-shadow:0 2px 1px rgba(0,0,0,.1)}.content footer{margin-top:40px;color:#020c15;font-size:1.6rem;max-width:225px;font-weight:400}@media screen and (orientation:landscape) and (max-height:450px){.content footer{display:none}}.content footer h5{margin:0 0 10px;font-size:1.9rem;text-decoration:underline}.content footer a{text-decoration:none;color:#08c;display:block;margin-top:5px;transition:color .3s}.content footer a:hover{color:#5db7e2;font-style:normal}</style>
</head>
<body>
<div class="grid-background"></div>
<svg id="client-leave" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1897.5 1101.8">
    <style>.st0{fill:#dce7f2;stroke:#004680;stroke-width:1.4;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10}.st1{fill:#fff;stroke:#004680;stroke-width:1.4;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10}.st2{fill:none;stroke:#004680;stroke-width:1.4;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10}.st3{fill:#fff}.st4{fill:#e1eaf2;stroke:#004680;stroke-width:1.4;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10}.st5{opacity:.1;fill:#457088}.st6{fill:#004680}.st7{fill:#dce7f2}.st8{fill:#dce7f2;stroke:#004680;stroke-width:1.1923;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10}.st9{fill:#8ad68a}.st10{fill:#a7e8a7}.st11{fill:none;stroke:#004680;stroke-width:1.1923;stroke-miterlimit:10}.st12{fill:#dce7f2;stroke:#004680;stroke-width:1.013;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10}.st13{fill:#c6f2c7}.st14{fill:none;stroke:#004680;stroke-width:1.0127;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10}.st15{fill:none;stroke:#004680;stroke-width:1.1923;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10}.st16{fill:none;stroke:none}.st17{fill-rule:evenodd;clip-rule:evenodd;fill:#151600}.st18{fill-rule:evenodd;clip-rule:evenodd;fill:#1f88ca}.st19{fill-rule:evenodd;clip-rule:evenodd;fill:#185f9e}.st20{fill-rule:evenodd;clip-rule:evenodd;fill:#26acef}.st21{fill-rule:evenodd;clip-rule:evenodd;fill:#fff}</style>
    <g id="trees_11_">
        <ellipse transform="matrix(5.419920e-03 -1 1 5.419920e-03 482.7352 2573.2361)" class="st7" cx="1535" cy="1043.9" rx="4.5" ry="7.9"/>
        <path class="st8" d="M1536,1044.6h-2.2c-0.4,0-0.8-0.3-0.8-0.8v-19.9c0-0.4,0.3-0.8,0.8-0.8h2.2c0.4,0,0.8,0.3,0.8,0.8v19.9
		C1536.7,1044.2,1536.4,1044.6,1536,1044.6L1536,1044.6z"/>
        <path class="st9" d="M1545.3,1018.1c0,6.3-5.1,11.3-11.3,11.3c-3.2,0-6.1-1.3-8.2-3.5c-1.9-2-3.2-4.8-3.2-7.9
		c0-6.3,5.1-11.3,11.3-11.3c4.9,0,9,3.1,10.6,7.5C1545.2,1015.5,1545.3,1016.8,1545.3,1018.1L1545.3,1018.1z"/>
        <path class="st10" d="M1544.7,1014.3c-0.9,7-6.9,12.4-14.2,12.4c-1.6,0-3.1-0.3-4.6-0.8c-1.9-2-3.2-4.8-3.2-7.9
		c0-6.3,5.1-11.3,11.3-11.3C1539,1006.8,1543.2,1009.9,1544.7,1014.3L1544.7,1014.3z"/>
        <path class="st11" d="M1545.3,1018.1c0,6.3-5.1,11.3-11.3,11.3c-3.2,0-6.1-1.3-8.2-3.5c-1.9-2-3.2-4.8-3.2-7.9
		c0-6.3,5.1-11.3,11.3-11.3c4.9,0,9,3.1,10.6,7.5C1545.2,1015.5,1545.3,1016.8,1545.3,1018.1L1545.3,1018.1z"/>
        <ellipse transform="matrix(0.3628 -0.9319 0.9319 0.3628 26.4444 2069.7471)" class="st3" cx="1526.7" cy="1015.5" rx="3.1" ry="1.8"/>
        <g>
            <ellipse transform="matrix(5.419920e-03 -1 1 5.419920e-03 463.81 2564.8376)" class="st7" cx="1521.3" cy="1049.3" rx="3.6" ry="6.3"/>
            <path class="st8" d="M1522,1049.8h-1.4c-0.4,0-0.8-0.3-0.8-0.8v-15.6c0-0.4,0.3-0.8,0.8-0.8h1.4c0.4,0,0.8,0.3,0.8,0.8v15.6
			C1522.7,1049.4,1522.4,1049.8,1522,1049.8z"/>
            <path class="st9" d="M1529.6,1028.7c0,4.9-4,9-9,9c-2.6,0-4.9-1.1-6.5-2.8c-1.6-1.6-2.5-3.9-2.5-6.2c0-4.9,4-9,9-9
			c3.9,0,7.2,2.5,8.5,5.9C1529.4,1026.7,1529.6,1027.7,1529.6,1028.7z"/>
            <path class="st10" d="M1529.1,1025.7c-0.8,5.6-5.5,9.9-11.4,9.9c-1.3,0-2.5-0.3-3.7-0.6c-1.6-1.6-2.5-3.9-2.5-6.2c0-4.9,4-9,9-9
			C1524.5,1019.7,1527.8,1022.2,1529.1,1025.7L1529.1,1025.7z"/>
            <path class="st11" d="M1529.6,1028.7c0,4.9-4,9-9,9c-2.6,0-4.9-1.1-6.5-2.8c-1.6-1.6-2.5-3.9-2.5-6.2c0-4.9,4-9,9-9
			c3.9,0,7.2,2.5,8.5,5.9C1529.4,1026.7,1529.6,1027.7,1529.6,1028.7z"/>
            <ellipse transform="matrix(0.3628 -0.9319 0.9319 0.3628 8.4365 2065.7224)" class="st3" cx="1514.7" cy="1026.7" rx="2.4" ry="1.5"/>
        </g>
    </g>
    <g id="tree_1_">
        <path class="st7" d="M380.9,339.6c-5.4,3.1-5.4,8.2,0,11.3s14.2,3.1,19.5,0s5.4-8.2,0-11.3C395.1,336.5,386.3,336.5,380.9,339.6z"/>
        <path class="st12" d="M390.5,344.7c-1.8,0-3.4-1.4-3.4-3.4v-14.4h6.6v14.4C393.9,343.2,392.4,344.7,390.5,344.7L390.5,344.7z"/>
        <path class="st13" d="M402.1,326.2l-12.2-45.3c-11.9,48.3-10.9,44.4-11.2,45.5C378.1,335,401.8,336.6,402.1,326.2z"/>
        <path class="st14" d="M386.9,293c0,0.1,0,0.2-0.1,0.4"/>
        <path class="st10" d="M402.1,326.2c-0.4,10.3-24,8.9-23.4,0.2v-0.1c7.1,2.8,19.1,1.4,18.4-6.1c-1.2-10.3-4.7-25.2-7.1-37.9
		c-1.8,7.4-3.5,13.4-4.9,18.3c1.3-5.3,2.9-11.8,4.8-19.6L402.1,326.2L402.1,326.2z"/>
        <path class="st14" d="M385.7,297.8l-0.5,2c-7,28.2-6.4,25.7-6.5,26.5c-0.6,8.6,23.2,10.1,23.4-0.2l-12.2-45.3
		c-0.8,3.4-1.6,6.5-2.3,9.4"/>
    </g>
    <g id="tree_2_">
        <path class="st7" d="M507.2,867.9c-4.5,2.6-4.5,6.8,0,9.4c4.5,2.6,11.8,2.6,16.2,0c4.4-2.6,4.5-6.8,0-9.4
		C519,865.3,511.7,865.3,507.2,867.9z"/>
        <path class="st12" d="M515.2,872.1c-1.5,0-2.8-1.2-2.8-2.8v-12h5.5v12C518,870.9,516.8,872.1,515.2,872.1L515.2,872.1z"/>
        <path class="st13" d="M524.9,856.7L514.7,819c-9.9,40.2-9.1,37-9.3,37.9C504.9,864.1,524.6,865.4,524.9,856.7z"/>
        <path class="st14" d="M512.2,829.1c0,0.1,0,0.2-0.1,0.3"/>
        <path class="st10" d="M524.9,856.7c-0.3,8.6-20,7.4-19.5,0.2v-0.1c5.9,2.3,15.9,1.2,15.3-5.1c-1-8.6-3.9-21-5.9-31.6
		c-1.5,6.2-2.9,11.2-4.1,15.2c1.1-4.4,2.4-9.8,4-16.3L524.9,856.7L524.9,856.7z"/>
        <path class="st14" d="M511.2,833.1l-0.4,1.7c-5.8,23.5-5.3,21.4-5.4,22.1c-0.5,7.2,19.3,8.4,19.5-0.2l-10.2-37.7
		c-0.7,2.8-1.3,5.4-1.9,7.8"/>
    </g>
    <g id="trees_4_">
        <path class="st7" d="M1540.9,700c-5.5,3.2-5.5,8.4,0,11.6c5.5,3.2,14.5,3.2,20.1,0c5.5-3.2,5.5-8.4,0-11.6
		C1555.4,696.7,1546.4,696.7,1540.9,700z"/>
        <path class="st8" d="M1551,705.3h-0.5c-1.8,0-3.2-1.4-3.2-3.2V687h6.8v15C1554.2,703.8,1552.8,705.3,1551,705.3z"/>
        <path class="st13" d="M1562.6,686.2l-12.6-46.6c-12.2,49.7-11.3,45.8-11.5,46.8C1537.9,695.3,1562.4,696.8,1562.6,686.2z"/>
        <path class="st10" d="M1562.6,686.2c-0.4,10.7-24.7,9.1-24.1,0.2v-0.1c7.3,2.9,19.6,1.4,18.9-6.2c-1.2-10.6-4.8-25.9-7.3-39.1
		c-1.9,7.6-3.6,13.8-5,18.9c1.3-5.5,3-12.1,4.9-20.2L1562.6,686.2L1562.6,686.2z"/>
        <path class="st15" d="M1545.2,659c-7.2,29.1-6.5,26.4-6.7,27.4c-0.6,8.9,23.8,10.4,24.1-0.2l-12.6-46.6c-1.2,4.7-2.2,9-3.1,12.7"/>
        <path class="st7" d="M1565.3,708.5c-5.5,3.2-5.5,8.4,0,11.6c5.5,3.2,14.5,3.2,20.1,0c5.5-3.2,5.5-8.4,0-11.6
		C1579.8,705.3,1570.8,705.4,1565.3,708.5z"/>
        <path class="st8" d="M1575.4,713.8h-0.5c-1.8,0-3.2-1.4-3.2-3.2v-15.1h6.8v15.1C1578.5,712.3,1577.2,713.8,1575.4,713.8z"/>
        <path class="st13" d="M1587,694.8l-12.6-46.6c-12.2,49.7-11.3,45.8-11.5,46.8C1562.3,703.9,1586.6,705.4,1587,694.8z"/>
        <path class="st10" d="M1587,694.8c-0.4,10.7-24.7,9.1-24.1,0.2v-0.1c7.3,2.9,19.6,1.4,18.9-6.2c-1.2-10.6-4.8-25.9-7.3-39.1
		c-1.9,7.6-3.6,13.8-5,18.9c1.3-5.5,3-12.1,4.9-20.2L1587,694.8L1587,694.8z"/>
        <path class="st15" d="M1569.1,669.5l-0.7,3c-5.9,23.9-5.3,21.6-5.5,22.5c-0.6,8.9,23.8,10.4,24.1-0.2l-12.6-46.6
		c-1.8,7.3-3.4,13.6-4.6,18.7"/>
        <path class="st7" d="M1536,720.7c-3.6,2-3.6,5.4,0,7.4s9.4,2,12.8,0c3.5-2,3.5-5.4,0-7.4S1539.5,718.7,1536,720.7z"/>
        <path class="st8" d="M1542.5,724.1h-0.4c-1.1,0-2-1-2-2v-9.7h4.4v9.7C1544.5,723.1,1543.5,724.1,1542.5,724.1z"/>
        <path class="st13" d="M1549.9,711.9l-8.2-29.9c-7.8,31.9-7.2,29.4-7.4,30.1C1534,717.7,1549.8,718.7,1549.9,711.9L1549.9,711.9z"/>
        <path class="st10" d="M1549.9,711.9c-0.2,6.8-15.9,5.9-15.5,0.1v-0.1c4.7,1.8,12.6,1,12.1-4c-0.8-6.8-3.1-16.7-4.7-25.1
		c-1.2,4.9-2.3,8.9-3.2,12.1c0.8-3.5,1.9-7.8,3.2-13L1549.9,711.9L1549.9,711.9z"/>
        <path class="st15" d="M1549.9,711.9l-8.2-29.9c-7.8,31.9-7.2,29.4-7.4,30.1C1534,717.7,1549.8,718.7,1549.9,711.9L1549.9,711.9z"/>
    </g>
    <g id="tree">

        <ellipse transform="matrix(5.419920e-03 -1 1 5.419920e-03 -377.6805 1378.7739)" class="st7" cx="504.3" cy="879.3" rx="3.6" ry="6.3"/>
        <path class="st8" d="M505,879.8h-1.4c-0.4,0-0.8-0.3-0.8-0.8v-15.6c0-0.4,0.3-0.8,0.8-0.8h1.4c0.4,0,0.8,0.3,0.8,0.8V879
		C505.7,879.4,505.4,879.8,505,879.8z"/>
        <path class="st9" d="M512.6,858.7c0,4.9-4,9-9,9c-2.6,0-4.9-1.1-6.5-2.8c-1.6-1.6-2.5-3.9-2.5-6.2c0-4.9,4-9,9-9
		c3.9,0,7.2,2.5,8.5,5.9C512.4,856.7,512.6,857.7,512.6,858.7z"/>
        <path class="st10" d="M512.1,855.7c-0.8,5.6-5.5,9.9-11.4,9.9c-1.3,0-2.5-0.3-3.7-0.6c-1.6-1.6-2.5-3.9-2.5-6.2c0-4.9,4-9,9-9
		C507.5,849.7,510.8,852.2,512.1,855.7L512.1,855.7z"/>
        <path class="st11" d="M512.6,858.7c0,4.9-4,9-9,9c-2.6,0-4.9-1.1-6.5-2.8c-1.6-1.6-2.5-3.9-2.5-6.2c0-4.9,4-9,9-9
		c3.9,0,7.2,2.5,8.5,5.9C512.4,856.7,512.6,857.7,512.6,858.7z"/>
        <ellipse transform="matrix(0.3628 -0.9319 0.9319 0.3628 -481.1823 1009.6872)" class="st3" cx="497.7" cy="856.7" rx="2.4" ry="1.5"/>
    </g>
</svg>

<div class="content">
    <svg id="upress-tobocat" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 130.6 121.5">
        <style>.robocat0{fill-rule:evenodd;clip-rule:evenodd}.robocat1{fill-rule:evenodd;clip-rule:evenodd;fill:#1f88ca}.robocat2{fill-rule:evenodd;clip-rule:evenodd;fill:#185f9e}.robocat3{fill-rule:evenodd;clip-rule:evenodd;fill:#26acef}.robocat4{fill-rule:evenodd;clip-rule:evenodd;fill:#151600}.robocat5{fill-rule:evenodd;clip-rule:evenodd;fill:#fff}.robocat6{fill-rule:evenodd;clip-rule:evenodd;fill:#e8e8e8}.robocat7{fill:#0c87c9}.robocat8{fill:#fff}.robocat9{fill-rule:evenodd;clip-rule:evenodd;fill:#b1b1b1}.robocat10{fill-rule:evenodd;clip-rule:evenodd;fill:#7e7e7e}.robocat11{fill:none;robocatroke:#151600;robocatroke-miterlimit:10}</style>
        <path class="robocat4" d="M124.9,3c-4.6-3.7-10.6-3.5-16-2c-3.1,0.8-6.2,2.1-9,3.5c-3.5,1.8-6.9,3.8-10,6.2c-6.5-2.5-13.3-4-20.2-4.4l0,0
	l0,0l-8.6,0l0,0l0,0c-6.9,0.4-13.8,1.9-20.2,4.4c-3.1-2.3-6.5-4.4-10-6.2c-2.9-1.4-5.9-2.7-9-3.5c-3.9-1-8.3-1.5-12.2-0.1
	C8.2,1.4,6.9,2.1,5.7,3C1.4,6.5,0,12.2,0,17.9c0,3.4,0.5,6.9,1,9.8c0.8,4,2,8,3.4,11.8C5.3,41.7,6.2,44,7.4,46
	c-1.5,5.2-2.3,10.5-2.5,15.9c0,0.8,0,1.5,0,2.3V75h0v15.1c0,3,0.6,6,1.7,8.8c2.6,6.8,8,11.9,14.4,14.9c0,0,10.6,4.7,14.4,5.4
	c14.7,2.8,45.3,3.3,59.9,0c3.8-0.9,14.5-5.5,14.5-5.5c6.4-3.1,11.6-8.2,14.3-14.9c1.1-2.8,1.7-5.8,1.7-8.8V64.2
	c0-6.2-0.8-12.3-2.5-18.2c1.2-2,2.1-4.3,2.9-6.4c1.5-3.8,2.6-7.8,3.4-11.8c0.5-2.5,0.9-5.2,1-8.1C130.8,13.4,129.6,6.8,124.9,3z"/>
        <path class="robocat1" d="M103.8,23.5C93.5,14.7,79.6,10.1,65.3,10C50.9,10.1,37,14.7,26.7,23.5C14.1,34.2,9.1,48.9,9.1,63.9v25.8
	c0,9.1,6.2,17.3,15.1,21.2c0.1,0,0.1,0.1,0.2,0.1c0,0,0.2,0.1,0.5,0.2c0.2,0.1,0.4,0.2,0.6,0.2c2.7,1,9.4,3.6,12.3,4.1
	c13.6,2.6,42,3.1,55.5,0c3.5-0.8,13.4-4.6,13.4-4.6c1.4-0.7,2.8-1.5,4-2.4c6.5-4.4,10.8-11.3,10.8-18.8V63.9
	C121.4,48.9,116.5,34.2,103.8,23.5z"/>
        <path class="robocat1" d="M8.2,5.9c-8.6,6.9-2.2,28.6,2.2,37c3-8,7.8-15.2,14.8-21.1c1.9-1.6,3.9-3.1,6-4.4c-5.3-4-15.1-8.1-19-5
	C8.4,15.5,8,23.2,9.2,28.6C7.5,21.9,7,14.1,11,10.9c5.2-4.2,15.6,1,21.8,5.6c1.8-1,3.6-2,5.5-2.8C29.7,7.3,15.4,0.1,8.2,5.9L8.2,5.9
	z"/>
        <path class="robocat2" d="M122.3,5.9c8.6,6.9,2.2,28.6-2.2,37c-3-8-7.8-15.2-14.8-21.1c-1.9-1.6-3.9-3.1-6-4.4c5.3-3.9,15.1-8,18.9-5
	c3.8,3.1,4.2,10.8,3.1,16.1c1.7-6.7,2.2-14.4-1.8-17.7c-5.2-4.2-15.5,1-21.8,5.5c-1.8-1-3.6-2-5.4-2.8
	C100.8,7.3,115.2,0.1,122.3,5.9L122.3,5.9z"/>
        <path class="robocat3" d="M40.8,16.8c6.8-2.8,13-3.6,13.8-1.7c0.8,1.9-4.2,5.7-11,8.5c-6.8,2.8-13,3.6-13.8,1.7
	C29,23.4,33.9,19.6,40.8,16.8L40.8,16.8z"/>
        <path class="robocat2" d="M103.9,23.5C93.6,14.7,79.7,10.1,65.3,10c-2.6,0-5.1,0.2-7.6,0.5c0.1,0,0.2,0,0.3,0
	c14.3,0.1,28.3,4.7,38.6,13.4c12.6,10.7,17.6,25.4,17.6,40.4v25.8c0,7.5-4.3,14.5-10.8,18.8c-1.3,0.9-2.6,1.7-4,2.4
	c0,0-9.9,3.8-13.4,4.6c-2.9,0.7-6.5,1.2-10.5,1.5c6.8-0.3,13.1-0.9,17.7-2c3.5-0.8,13.4-4.6,13.4-4.6c1.4-0.7,2.8-1.5,4-2.4
	c6.5-4.4,10.8-11.3,10.8-18.8V63.9C121.5,48.9,116.5,34.2,103.9,23.5z"/>
        <path class="robocat4" d="M69.3,101.7h-8l-2.8,4.9H37.4c-2.7,0-5.4-0.6-7.8-1.9c-6.8-3.4-10.8-10.7-10.8-18.2V70.8c0-1.8,0.3-3.5,0.9-5.2
	c2.6-7.2,10.3-11.5,17.2-14c8.9-3.2,19.1-4.4,28.5-4.4c9.4,0,19.6,1.2,28.5,4.4c6.8,2.4,14.5,6.7,17.2,14c0.6,1.7,0.9,3.4,0.9,5.2
	v15.7c0,7.5-4,14.8-10.8,18.2c-2.4,1.2-5.1,1.9-7.8,1.9H72.1l-0.8-1.4L69.3,101.7L69.3,101.7z"/>
        <path class="robocat5" d="M78,80.8c0,7,5.7,12.7,12.7,12.7c6.8,0,12.3-5.3,12.7-12h6.8v5c0,10.1-7.6,18.3-16.9,18.3H73.2l-0.3-0.6
	l-2.5-4.3h-4.2v-7.1c0-2.6-0.3-2.7,2.1-3.9c2.5-1.2,4.6-1.9,4.6-2.8c0-3-15-3-15,0c0,0.9,2.2,1.7,4.8,2.9c2.3,1.1,1.9,1.3,1.9,3.8
	v7.1h-4.2l-2.5,4.3l-0.3,0.6H37.4c-9.3,0-16.9-8.2-16.9-18.3v-5h6.8c0.4,6.7,5.9,12,12.7,12c7,0,12.7-5.7,12.7-12.7 M27.4,80.1h-6.8
	v-9.3c0-29,89.6-29,89.6,0l0,0v9.3h-6.8 M100.3,80.8c0,5.3-4.3,9.6-9.6,9.6c-5.3,0-9.6-4.3-9.6-9.6 M49.6,80.8
	c0,5.3-4.3,9.6-9.6,9.6s-9.6-4.3-9.6-9.6 M102.2,80.8c0,6.4-5.2,11.6-11.6,11.6c-6.4,0-11.6-5.2-11.6-11.6 M51.6,80.8
	c0,6.4-5.2,11.6-11.6,11.6c-6.4,0-11.6-5.2-11.6-11.6"/>
        <path class="robocat6" d="M89.5,102.8h3.8c2.1,0,4.2-0.5,6.1-1.5c5.5-2.8,8.7-8.8,8.7-14.8v-2.9h-3.1c-1,5.2-4.7,9.4-9.6,11.1
	C94.2,97.8,92.2,100.7,89.5,102.8L89.5,102.8z M96.7,67.5c4.3,1.9,7.5,5.9,8.4,10.6h3.1v-7.3c0-1.3-0.2-2.6-0.7-3.9
	c-2.2-6-9.3-9.7-14.9-11.7c-3.6-1.3-7.5-2.3-11.5-2.9C88,55.2,95.1,60.1,96.7,67.5L96.7,67.5z"/>
        <line class="robocat11" x1="30.4" y1="80.8" x2="49.6" y2="80.8"/>
        <line class="robocat11" x1="81" y1="80.8" x2="100.3" y2="80.8"/>
    </svg>

    <h1><span data-trans="where_to">403 Forbidden</span></h1>
    <h2>
        <span data-trans="access_denied">You are not authorized to perform this action,</span>
        <br>
        <span data-trans="contact_webmaster">Please contact the webmaster.</span>
    </h2>
</div>

<script>
    document.title = strings.title;
    document.querySelector('.content').style.direction = strings.dir;
    var entries = document.querySelectorAll('[data-trans]');
    for(var i = 0; i < entries.length; i++) {
        entries[i].innerHTML = strings[entries[i].dataset.trans];
    }
</script>
</body>
</html>
